#Faça uma função que, a partir das medidas dos lados de um retângulo, calcule a área e o perímetro deste retângulo. 
def funcao(x1,x2):
    area = x1*x2
    perimetro = 2*(x1+x2)
    return area,perimetro 