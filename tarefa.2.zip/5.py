#Faça uma função que, dado o tamanho do lado de um quadrado e retorne a sua área.   
def funcao(x):
    return x*x