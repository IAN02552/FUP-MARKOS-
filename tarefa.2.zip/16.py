#Faça uma função que receba um valor inteiro positivo em segundos, e retorne-o em horas, minutos e segundos.    
def funcao(x):
    horas = x//3600
    minutos = (x%3600)//60
    segundos = (x%3600)%60
    return horas,minutos,segundos