#Crie uma função que permita fazer a conversão cambial de Dólares para Reais. Considere como taxa de câmbio US$ 1,0 = R$5,27.
def funcao(x):
    return x * 5.27
