#Crie uma função que receba como parâmetro um número inteiro e devolva o seu dobro. 
def funcao(x):   
    return x * 2
