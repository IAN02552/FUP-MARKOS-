n1 = float(input(''))
print(f"{n1*n1:.2f}")