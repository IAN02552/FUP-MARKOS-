n1 = str(input(""))
print(n1.upper())