n1 = str(input(""))
n2 = int(input(""))
n3 = int(input(""))
print(f"{n1[n2-1:n3]}")