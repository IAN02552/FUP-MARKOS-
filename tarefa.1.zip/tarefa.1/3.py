n1 = int(input(''))
print(n1-1)
print(n1+1)