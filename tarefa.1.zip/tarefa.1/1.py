n1 = float(input(''))
print(f"{n1*(9.0/5.0)+32:.2f}")