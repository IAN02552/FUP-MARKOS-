n1 = int(input(''))
nota100 = n1//100
n1 = n1%100
nota50 = n1//50
n1 = n1%50
nota20 = n1//20
n1= n1%20
nota10 = n1//10
n1= n1%10
nota5 = n1//5
n1 = n1%5
nota2 = n1//2
n1 = n1%2
nota1 = n1//1
print(nota100)
print(nota50)
print(nota20)
print(nota10)
print(nota5)
print(nota2)
print(nota1)