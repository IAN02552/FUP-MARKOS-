n1 = float(input(''))
print(f"{n1**2:.2f}")