n1 = str(input(""))
n2 = str(input(""))
n3 = int(input())
print(n1.find(n2,n3))