n1 = float(input(''))
n2 = float(input(''))
n3 = ((n1**2)+(n2**2))**(1/2)
print(f"{n3:.2f}")