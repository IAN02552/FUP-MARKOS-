n1 = float(input(''))
print(f"{n1/3.6:.2f}")