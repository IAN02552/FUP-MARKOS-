n1 = str(input(""))
l1 = str(input(""))
l2 = str(input(""))
print(n1.replace(l1,l2))