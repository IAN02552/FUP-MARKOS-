n1 = str(input(""))
print(len(n1))