n1 = float(input(''))
print(f"{n1*3.1415926535/180:.2f}")