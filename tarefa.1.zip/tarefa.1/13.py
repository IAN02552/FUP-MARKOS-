n1 = int(input(''))
n2 = n1%10
n3 = (n1//10)%10
n4 = n1//100
n5 = n2*100+n3*10+n4
print(n5)