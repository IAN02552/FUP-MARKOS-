n1 = float(input(''))
n2 = float(input(''))
n3 = float(input(''))
n4 = float(input(''))
n5 = n1+n2+n3
print(f"{n4*(n1/n5):.2f}")
print(f"{n4*(n2/n5):.2f}")
print(f"{n4*(n3/n5):.2f}")