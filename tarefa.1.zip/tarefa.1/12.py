n1 = float(input(''))
n2 = n1*0.46
n3 = n1*0.32
n4 = n1*0.22
print(f"{n2:.2f}")
print(f"{n3:.2f}")
print(f"{n4:.2f}")