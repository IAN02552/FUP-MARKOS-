n1 = float(input(''))
n2 = float(input(''))
print(f"{n1*n2:.2f}")
print(f"{2*(n1+n2):.2f}")