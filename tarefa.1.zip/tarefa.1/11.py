n1 = float(input(''))
print(f"{n1+(n1*0.2137):.2f}")