n1 = str(input(""))
n2 = str(input(""))
i = len(n2)
i = i*-1
print(n2 in n1[i::])